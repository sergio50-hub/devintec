/////////////////////////
//Glass Cup Enterprise///
/////////////////////////

This is a basic introduction to CRUD operatin for beginners 
who wish to learn mysql and php,

this script is free to be used and modified by anyone

database
An sql file containing database table and rows are is included 
so all you need to do is just to import them.
 
 edit the parameters in the includes/database.php
 to match your own database connectivity.