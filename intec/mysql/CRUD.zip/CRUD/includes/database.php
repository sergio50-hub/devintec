<?php
$con = mysqli_connect('localhost','root','','db_intec');
?>