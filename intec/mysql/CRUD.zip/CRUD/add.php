
<?php
include "includes/database.php";

?>

<html>
<head></head>

<title>glass cup enterprise || Add contact</title>
<body>


<div>
<a href="index.php">home</a>
<a href="add.php">add contact</a>
</div>

<h3>Add Contact</h3>

<?php
if (isset($_POST['save'])) {
	/* $name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address']; */
	$name = $_POST['name'];
	$aw = $_POST['attendance'];
	$opleidingen = $_POST['opleidingen'];

$query ="INSERT INTO tbl_attendances (fld_firstname,fld_aw,fld_opleidingen) VALUES ('$name','$aw','$opleidingen')";
echo ("$query");
	if ($con->query($query)) {
		echo "contact successfully added";
	}else{
		echo "an error occured";
	}
}


?>



<form action="" method="post">
<input type="text" name="name" placeholder="First name">
<br>
<fieldset>
	<legend>Attended?</label>
	<label>Yes</label><input name="attendance" type="radio" value="1">
	<label>No</label><input name="attendance" type="radio" value="0">
</fieldset>
<br>
<input type="text" name="opleidingen" placeholder="Opleiding">
<br>
<!-- <input type="text" name="phone" placeholder=" Your phone number">
<br>
<input type="text" name="email" placeholder="Your email">
<br>
<input type="text" name="address" placeholder="Your address">
<br> -->
<input type="submit" name="save" value="save" >
</form>


</table>
</body>

</html>