<?php
include "includes/database.php";
$id = $_REQUEST['id'];

mysqli_query($con,"DELETE FROM tbl_attendances WHERE fld_id=$id");
header("location: index.php");
?>