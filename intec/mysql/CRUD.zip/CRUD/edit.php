
<?php 
include "includes/database.php";
?>

<html>
<head></head>

<title>glass cup enterprise || Edit contact</title>

<body>


<div>
<a href="index.php">home</a>
<a href="add.php">add contact</a>
</div>



<body>

	<h4>Edit Contact</h4>

	<?php
if (isset($_POST['save'])) {
	$id = $_POST['id'];
	$name = $_POST['name'];
	$aw = $_POST['attendance'];
	$opleidingen = $_POST['opleidingen'];
	/* $phone = $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address'];*/

$query ="UPDATE tbl_attendances SET fld_firstname='$name',fld_aw='$aw',fld_opleidingen='$opleidingen' WHERE fld_id=$id";

	if ($con->query($query)) {
		echo "contact successfully updated";
	}else{
		echo "an error occured".$con->error;
	}
}

?>

<?php
$id = $_REQUEST['id'];
$getcontacts = mysqli_query($con,"SELECT * FROM tbl_attendances WHERE fld_id=$id");

while ($contacts=mysqli_fetch_array($getcontacts)) {

	/* $name = $contacts['name'];
	$phone = $contacts['phone'];
	$email = $contacts['email'];
	$address = $contacts['address']; */
	$name = $contacts['fld_firstname'];
	$aw = $contacts['fld_aw'];
	$opleidingen = $contacts['fld_opleidingen'];

?>


<form action="" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>">

<input type="text" name="name" placeholder="Full name" value="<?php echo $name; ?>">
<br>
<fieldset>
	<legend>Attended?</label>
	<label>Yes</label><input name="attendance" type="radio" value="1" <?php if($aw == "1"){echo "checked";} ?> >
	<label>No</label><input name="attendance" type="radio" value="0" <?php if($aw == "0"){echo "checked";} ?>>
</fieldset>
<br>
<input type="text" name="opleidingen" placeholder="Opleiding" value="<?php echo $opleidingen;?>">
<br>
<input type="submit" name="save" value="save" >
</form>


<?php
}
?>

</table>
</body>

</html>